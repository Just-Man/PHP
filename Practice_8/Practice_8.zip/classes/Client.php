<?php

/**
 * Created by PhpStorm.
 * User: just
 * Date: 07.03.16
 * Time: 14:54
 */
class Client extends Person
{
    protected $city;

    protected $street;

    protected $strNumber;
}